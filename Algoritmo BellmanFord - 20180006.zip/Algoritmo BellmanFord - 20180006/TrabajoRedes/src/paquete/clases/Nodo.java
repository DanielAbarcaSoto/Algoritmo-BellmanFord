package paquete.clases;

// Clase Nodo
// Cada nodo en la lista enlazada equivaldría a una arista

public class Nodo {
    private int origen; // Vertice origen
    private int destino;  // Vertice destino
    private int peso;  // Peso de la arista
    private Nodo siguiente;  // Siguiente nodo(arista) en la lista
    
    // Constructor
    public Nodo(int origen, int destino, int peso) {
        this.origen = origen;
        this.destino = destino;
        this.peso = peso;
        this.siguiente = null;
    }

    public int getOrigen() {
        return origen;
    }

    public void setOrigen(int origen) {
        this.origen = origen;
    }

    public int getDestino() {
        return destino;
    }

    public void setDestino(int destino) {
        this.destino = destino;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }
        
    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }   
}
