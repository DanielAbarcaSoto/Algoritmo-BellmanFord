package paquete.clases;

import java.io.*;

public class archivo {
    
    public String[] leerTxT(String dir)
    {
        String[] texto = null;
        
        try{
            // Se lee el archivo que se encuentra en la direccion dir
            // y se guarda en el búfer
            FileReader fl = new FileReader(dir);
            BufferedReader bf = new BufferedReader(fl);
            
            // Se crea una variable temporal
            String temp ="";
            String bfRead;
            
            // Se lee todas las lineas almacenadas en el búfer
            while((bfRead=bf.readLine())!=null)
            {
                // Se almacena en temp cada linea y se separa en saltos de linea
                temp+=bfRead;
                temp+="\n";
            }
            // Se separa los caracteres en temp segun los saltos de linea
            // Se almacena en el array texto los conjuntos de caracteres ya separados
            texto = temp.split("\n");
        }
        catch(Exception e)
        {
            // Mostrar un mensaje en caso no se haya el archivo
            // Puede suceder si se ingreso mal el nombre o la direccion de este
            System.out.println("No se encontró archivo");
            System.out.println("Vuelva a intentar");
        }
        
        return texto;
    }
}