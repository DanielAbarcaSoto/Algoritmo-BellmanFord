package paquete.clases;

public class bellmanford {
    
    public static void mostrarMatriz(int [][] matriz)
        {
            // Imprime la cabecera de cada columna
            for(int k=0;k<matriz.length;k++)
            {
                System.out.print("\tV" + k);
            }System.out.println("");
            
            for (int i = 0; i < matriz.length; i++) 
            {
                // Imprime la cabecera de cada fila
                System.out.print("V" + i + "\t");
                // Imprime los valores de cada fila
                for (int j = 0; j < matriz[i].length; j++) 
                {
                    System.out.print(matriz[i][j]+"\t");
                }
                System.out.println("");
            }
        }
        
        public static void crearMatriz(int[][] matriz, ListaES lista)
        {
            for(int i=0;i<matriz.length;i++)
            {
                for(int j=0;j<matriz.length;j++)
                {
                    // Se crea un nodo pivot para recorrer la lista enlazada
                    Nodo ptr=lista.getPrimero();
                    while(ptr!=null){ // Recorre la lista hasta que se llegue a nulo
                        
                        // En el origen del pivot sea igual a i y su destino con j
                        if((ptr.getOrigen()==i)&&(ptr.getDestino()==j)) 
                        {
                            //  Almacenar el peso en la posicion actual de la matriz
                            matriz[i][j] = ptr.getPeso();
                        }
                        ptr=ptr.getSiguiente();
                    }
                }
            }
        }
    
        public static void MostrarTablaBellman(int Vertices, int[] distancia, int[] prev)
        {
            // Se imprimen todos los vertices del grafo
            System.out.print("Vértices"+"\t");
            for(int i=0;i<Vertices;i++)
            {
                System.out.print(i+"\t");
            }System.out.println("");
            
            // Se imprime la distancia que hay entre el vertice origen con cada uno de los vertices
            System.out.print("Distancia"+"\t");
            for(int i=0;i<Vertices;i++)
            {
                System.out.print(distancia[i]+"\t");
            }System.out.println("");
            
            // Se imprime el vertice previo de cada vertice para llegar a este
            System.out.print("Previo"+"\t"+"\t");
            for(int i=0;i<Vertices;i++)
            {
                System.out.print(prev[i]+"\t");   
            }System.out.println("");
            
        }
        
    public static void relajacion(int actual, int adyacente, int peso, int[] distancia, int[] prev)
    {
        // En caso la distancia del vertice destino sea menor 
        // a la suma entre la distancia del vertice actual y el peso de la arista que los conecta
        if(distancia[actual]+peso<distancia[adyacente])
        {
            // Cambiar la distancia y previo del vertice destino
            distancia[adyacente]=distancia[actual]+peso;
            prev[adyacente]=actual;
        }
    }
        
    public static void BellmanFord(int[][] matriz, int origen){
        int tamaño = matriz.length;
        int[] distancia = new int[tamaño];
        int[] prev = new int[tamaño];
        // Inicializar distancia y previo
        for(int i=0;i<tamaño;i++){
            distancia[i]=9999;
            prev[i]=-1;
        }
        // Se cambia el valor de distancia para el vertice origen
        distancia[origen]=0;
        for(int k=0;k<tamaño-1;k++)
        {
            // Se recorre para cada arista
            for(int i=0;i<tamaño;i++)
            {
                for(int j=0;j<tamaño;j++)
                {
                    // Si la posicion actual de la matriz no es 0, quiere decir que hay una arista
                    if(matriz[i][j]!=0)
                    {
                        // Se ejecuta el metodo relajacion para calcular las distancias
                        relajacion(i,j,matriz[i][j],distancia,prev);
                    }
                }
            }
        }
        for(int i=0;i<tamaño;i++)
        {
            for(int j=0;j<tamaño;j++)
            {
                // Si la posicion actual de la matriz no es 0, quiere decir que hay una arista
                if(matriz[i][j]!=0)
                {
                    if(distancia[i]+matriz[i][j]<distancia[j])
                    {
                        System.out.println("Existe ciclo negativo");
                        break;
                    }
                }
            }
        }
        MostrarTablaBellman(tamaño, distancia, prev);
    }
    
    public static void main(String[] args) {
        
        // Booleano que determinará si el código se sigue ejecutando o no
        boolean estado = true;
        
        // Empieza el tiempo respecto al proceso de leer archivo
        long inicio1 = System.nanoTime();
        
        archivo txt = new archivo();
        // Lee el texto del archivo en la direccion dir
        String[] texto = txt.leerTxT("C:\\Users\\IDEAPAD 110\\Desktop\\UNIVERSIDAD\\6 Ciclo\\Redes\\Trabajo\\Avance trabajo_20180006\\Escenario1.txt");
        
        ListaES aristas = new ListaES();
        
        int numVertices = Integer.parseInt(texto[0]);
        int numAristas = Integer.parseInt(texto[1]);
        int VerticeOrigen = Integer.parseInt(texto[2]);
        int cantAristas = 0;
        
        // Empieza en la cuarta linea, ya que desde ahi se empieza a ingresar los valores de las aristas
        for(int i=3; i<texto.length; i++)
        {
            // Se repite el proceso de almacenar en un array como en la clase archivo
            // solo que en este caso se separan los caracteres por '/'
            String temp1 = texto[i];
            String[] temp2 = temp1.split("/");
            
            // Se asignan los valores de cada arista 
            int origen = Integer.parseInt(temp2[0]);
            int destino = Integer.parseInt(temp2[1]);
            int peso = Integer.parseInt(temp2[2]);
            
            // CONTROL DE ERROR: NO CONTINUAR CON EL CÓDIGO SI SE INGRESO UN VERTICE QUE NO ESTE DENTRO DE LA CANTIDAD DE VERTICES
            if((origen < 0 || origen >= numVertices) || (destino < 0 || destino >= numVertices))
            {
                System.out.println("No se puede ejecutar el algoritmo debido a incompatibilidad entre los datos:");
                System.out.println("Se ingreso mal un vertice en la arista " + (cantAristas+1));
                if((origen < 0 || origen >= numVertices) && (destino < 0 || destino >= numVertices))
                {
                    System.out.println("Error en ambos vertices de la arista");
                }
                else if (destino < 0 || destino >= numVertices)
                {
                    System.out.println("Error en vertice destino de la arista");
                }
                else{
                    System.out.println("Error en vertice origen de la arista");
                }
                estado = false;
                break;
            }
            
            // Se inserta una nueva arista con los valores asignados
            aristas.insertar(origen, destino, peso);
            cantAristas++;
        }
        
        
        // Termina el tiempo del proceso leer archivo y se calcula su duración
        long fin1 = System.nanoTime();
        double timeArchivo = (fin1 - inicio1);       
        
        if(estado)
        {
            // CONTROL DE ERROR: NO EJECUTAR ALGORITMO EN CASO SE HAYA INGRESADO UNA ARISTA DE MÁS O FALTE UNA(S)
        if(numAristas!=cantAristas)
        {
            int diferencia = numAristas - cantAristas;
            if(diferencia<0)
            {
                System.out.println("No se puede ejecutar el algoritmo debido a incompatibilidad entre los datos:");
                System.out.println("Se agregó " + (diferencia*-1) + " aristas de más");
            }
            else
            {
                System.out.println("No se puede ejecutar el algoritmo debido a incompatibilidad entre los datos:");
                System.out.println("Falto agregar " + diferencia + " arista(s)");
            }
        }
        else
        {
            System.out.println("Numero de Vertices: " + numVertices);
        System.out.println("Numero de Aristas: " + numAristas);
        System.out.println("Vertice de Origen: " + VerticeOrigen);
        System.out.println("");

        int[][] grafo = new int[numVertices][numVertices];
        
        // Empieza el tiempo respecto al proceso de crear la matriz
        long inicio2 = System.nanoTime();
        
        System.out.println("Matriz Utilizada");
        crearMatriz(grafo, aristas);
        mostrarMatriz(grafo);
        System.out.println("");
        
        // Termina el tiempo del proceso de crear la matriz y se calcula su duración
        long fin2 = System.nanoTime();
        double timeMatriz = (fin2 - inicio2);
        
        // Empieza el tiempo respecto al proceso del calculo del algoritmo de Bellman-Ford
        long inicio3 = System.nanoTime();
        
        System.out.println("Tabla de Bellman-Ford");
        BellmanFord(grafo, VerticeOrigen);
        
        // Termina el tiempo del proceso del calculo del algoritmo de Bellman-Ford y se calcula su duración
        long fin3 = System.nanoTime();
        double timeBellmanFord = (fin3 - inicio3);
        
        // Se imprimen los resultados
        System.out.println("\nResultados:" + 
                "\nTiempo para leer el archivo y guardar la información: " + timeArchivo +
                "\nTiempo para crear y mostrar la matriz: " + timeMatriz + 
                "\nTiempo para calcular el algoritmo Bellman-Ford: " + timeBellmanFord);
        }
        }               
    }    
}
