package paquete.clases;

// Clase ListaES
// Lista enlazada simple que agrupará las aristas del grafo

public class ListaES {
    private Nodo primero; // Primera arista ingresada
    private int talla; // Tamaño de la lista

    // Constructor
    public ListaES() {
        this.primero=null;
        this.talla=0;
    }

    public Nodo getPrimero() {
        return primero;
    }

    public int getTalla() {
        return talla;
    }
    
    // Metodo insertar, que permitirá el ingreso de un nuevo nodo(arista) en la lista
    public void insertar(int origen, int destino, int peso){
        Nodo x=new Nodo(origen, destino, peso); // Se crea un nuevo nodo(arista)
        // Seteamos los valores del nodo(arista)
        x.setOrigen(origen);
        x.setDestino(destino);
        x.setPeso(peso);
        x.setSiguiente(null);
        
        // En caso de que la lista este vacia
        if(primero==null){
            primero=x;
        }
        // En caso de que la lista no este vacia
        else{
            Nodo ptr=primero; // Se crea un pivot
            // Se recorre la lista hasta el final
            while(ptr.getSiguiente()!=null){
                ptr=ptr.getSiguiente();
            }
            // Se asigna como siguiente nodo al nuevo nodo(arista)
            ptr.setSiguiente(x);
        }
        talla++;
    }   
}
